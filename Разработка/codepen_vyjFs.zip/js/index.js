'use strict';
  angular.element(document).ready(function(){
    console.log("::prepare");
    
    var $inj = angular.bootstrap(document.body, ['use']);
    var $rootScope = $inj.get("$rootScope");
    
    console.log("::loaded");
    
    $rootScope.$broadcast("init", "hello");
    $rootScope.$digest();
    
    
     console.log("::finalize");
  });

angular.module("use", [])
  .run(function(){
    console.log("::use::run");
  })

  .controller("FooCtrl", ["$scope", function($scope){
    console.log("::use::ctrl");
    $scope.foobar = "bug";

    $scope.$on("init", function(ev, data){
      console.log("::use::init");
      $scope.foobar = data + " " + $scope.foobar;
    });
  }])

;
